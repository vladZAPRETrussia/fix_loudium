str0ct0r3.exe
this is destructive,
if u test in vm
dont worry:)
if u test in pc
you disk hack
loud+epilepsy

u need launch for admin
launch virus = disk delete