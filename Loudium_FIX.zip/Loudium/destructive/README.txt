--       ------  -      -  ------  ------  -      -  -     -         ------  -    -  ------
--      -      - -      -  -     -   --    -      -  --   --         -       -    -  -     
--      -      - -      -  -     -   --    -      -  - - - -         -----    -  -   ----- 
--      -      - -      -  -     -   --    -      -  -  -  -         -         --    -     
--      -      - -      -  -     -   --    -      -  -     -  --     -        -  -   -     
-------  ------   ------   ------  ------   ------   -     -  --     ------  -    -  ------this is destructive bro...
if you test in vmvare, virtual box, windows sandbox, hyper-v, apponfly
dont worry:)
if you test in real pc
you pc = delete
this is destructive
very loud
epilepsy