--       ------  -      -  ------  ------  -      -  -     -         ------  -    -  ------
--      -      - -      -  -     -   --    -      -  --   --         -       -    -  -     
--      -      - -      -  -     -   --    -      -  - - - -         -----    -  -   ----- 
--      -      - -      -  -     -   --    -      -  -  -  -         -         --    -     
--      -      - -      -  -     -   --    -      -  -     -  --     -        -  -   -     
-------  ------   ------   ------  ------   ------   -     -  --     ------  -    -  ------this is safety bro:D
if you test in vmvare, virtual box, windows sandbox, hyper-v, apponfly
dont worry:)
if you test in real pc
you pc = survive
this is safe
very loud
epilepsy
Test in real pc: RECOMENDED